#!/bin/bash

# python capcha_train.py --model resnet34
python capcha_train.py --model resnet50
python capcha_train.py --model wide_resnet